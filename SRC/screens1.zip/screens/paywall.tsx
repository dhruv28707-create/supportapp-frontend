import React from "react";
import {
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  Alert,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useNavigation } from "@react-navigation/native";
import { useToken } from "../context/TokenContext";

const PRO_FEATURES = [
  "👨‍👩‍👧 9 personalities unlocked",
  "💬 15,000 tokens per session",
  "🙏 All Guide variants",
  "🤝 Friend & Best Friend",
  "🎓 Mentor access",
  "⚡ Priority responses",
];

const ULTIMATE_FEATURES = [
  "✨ All Pro features",
  "🛠️ Custom personality",
  "💎 30,000 tokens per session",
  "🔮 Early access to new features",
];

export default function PaywallScreen() {
  const navigation = useNavigation();
  const { tier } = useToken();

  const handleSubscribe = (plan: string) => {
    Alert.alert(
      "Coming Soon 🚀",
      `${plan} plan will be available very soon. We'll notify you when it launches!`,
      [{ text: "Got it!", style: "default" }]
    );
  };

  return (
    <SafeAreaView style={styles.safe} edges={["top"]}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Text style={styles.backText}>← Back</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Upgrade</Text>
        <View style={{ width: 60 }} />
      </View>

      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {/* Hero */}
        <Text style={styles.heroEmoji}>💛</Text>
        <Text style={styles.heroTitle}>You deserve more support</Text>
        <Text style={styles.heroSub}>
          Unlock more companions and longer conversations
        </Text>

        {/* Current plan badge */}
        <View style={styles.currentPlanBadge}>
          <Text style={styles.currentPlanText}>
            Current plan: {tier.toUpperCase()}
          </Text>
        </View>

        {/* Pro Card */}
        <View style={[styles.planCard, styles.proCard]}>
          <View style={styles.planHeader}>
            <View>
              <Text style={styles.planName}>Pro</Text>
              <Text style={styles.planPrice}>₹99 / month</Text>
            </View>
            <View style={styles.popularBadge}>
              <Text style={styles.popularText}>POPULAR</Text>
            </View>
          </View>

          <View style={styles.divider} />

          {PRO_FEATURES.map((f, i) => (
            <Text key={i} style={styles.featureItem}>{f}</Text>
          ))}

          <TouchableOpacity
            style={[styles.subscribeBtn, styles.proBtn]}
            onPress={() => handleSubscribe("Pro")}
            activeOpacity={0.85}
          >
            <Text style={styles.subscribeBtnText}>Coming Soon</Text>
          </TouchableOpacity>
        </View>

        {/* Ultimate Card */}
        <View style={[styles.planCard, styles.ultimateCard]}>
          <View style={styles.planHeader}>
            <View>
              <Text style={[styles.planName, { color: "#FFF8F0" }]}>Ultimate</Text>
              <Text style={[styles.planPrice, { color: "#F5D9B8" }]}>Pricing TBD</Text>
            </View>
            <Text style={styles.crownEmoji}>👑</Text>
          </View>

          <View style={[styles.divider, { backgroundColor: "rgba(255,255,255,0.2)" }]} />

          {ULTIMATE_FEATURES.map((f, i) => (
            <Text key={i} style={[styles.featureItem, { color: "#FFF8F0" }]}>{f}</Text>
          ))}

          <TouchableOpacity
            style={[styles.subscribeBtn, styles.ultimateBtn]}
            onPress={() => handleSubscribe("Ultimate")}
            activeOpacity={0.85}
          >
            <Text style={[styles.subscribeBtnText, { color: "#C8702A" }]}>Coming Soon</Text>
          </TouchableOpacity>
        </View>

        <Text style={styles.footer}>
          Payments are secure. Cancel anytime.{"\n"}
          Subscriptions renew every 30 days.
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#FDF6EC" },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: "#F0DCC8",
  },
  backBtn: { width: 60 },
  backText: { color: "#C8702A", fontSize: 15, fontWeight: "600" },
  headerTitle: { fontSize: 18, fontWeight: "700", color: "#3D2000" },

  content: { padding: 24, paddingBottom: 48, alignItems: "center" },

  heroEmoji: { fontSize: 48, marginBottom: 12 },
  heroTitle: {
    fontSize: 24,
    fontWeight: "800",
    color: "#3D2000",
    textAlign: "center",
  },
  heroSub: {
    fontSize: 14,
    color: "#B0937A",
    textAlign: "center",
    marginTop: 6,
    marginBottom: 20,
  },

  currentPlanBadge: {
    backgroundColor: "#F0DCC8",
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 6,
    marginBottom: 28,
  },
  currentPlanText: {
    fontSize: 13,
    fontWeight: "700",
    color: "#C8702A",
    letterSpacing: 0.5,
  },

  planCard: {
    width: "100%",
    borderRadius: 24,
    padding: 24,
    marginBottom: 20,
    elevation: 4,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 12,
  },
  proCard: {
    backgroundColor: "#FFFFFF",
    borderWidth: 2,
    borderColor: "#C8702A",
  },
  ultimateCard: {
    backgroundColor: "#C8702A",
  },

  planHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 16,
  },
  planName: {
    fontSize: 22,
    fontWeight: "800",
    color: "#3D2000",
  },
  planPrice: {
    fontSize: 15,
    fontWeight: "600",
    color: "#C8702A",
    marginTop: 2,
  },
  popularBadge: {
    backgroundColor: "#C8702A",
    borderRadius: 8,
    paddingHorizontal: 10,
    paddingVertical: 4,
  },
  popularText: {
    fontSize: 11,
    fontWeight: "800",
    color: "#FFF",
    letterSpacing: 0.5,
  },
  crownEmoji: { fontSize: 28 },

  divider: {
    height: 1,
    backgroundColor: "#F0DCC8",
    marginBottom: 16,
  },

  featureItem: {
    fontSize: 15,
    color: "#3D2000",
    marginBottom: 10,
    fontWeight: "500",
  },

  subscribeBtn: {
    marginTop: 20,
    borderRadius: 14,
    paddingVertical: 15,
    alignItems: "center",
  },
  proBtn: {
    backgroundColor: "#C8702A",
  },
  ultimateBtn: {
    backgroundColor: "#FFF8F0",
  },
  subscribeBtnText: {
    fontSize: 16,
    fontWeight: "700",
    color: "#FFF8F0",
    letterSpacing: 0.3,
  },

  footer: {
    fontSize: 12,
    color: "#B0937A",
    textAlign: "center",
    marginTop: 8,
    lineHeight: 18,
  },
});